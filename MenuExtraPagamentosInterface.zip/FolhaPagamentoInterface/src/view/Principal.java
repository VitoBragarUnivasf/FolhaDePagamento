/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import java.awt.Toolkit;
import ValidaCPF.validaCPF;
import static java.lang.Float.parseFloat;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sql.PooledConnection;
import javax.swing.JOptionPane;
import oracle.jdbc.OraclePreparedStatement;
import oracle.jdbc.pool.OracleConnectionPoolDataSource;

/**
 *
 * @author jonas
 */
public class Principal extends javax.swing.JFrame {

    
    
    
    /**
     * Creates new form Principal
     */
    public Principal() {
        //this.setUndecorated(true);
        //this.setAlwaysOnTop(true);
        this.setResizable(false);
        this.setVisible(true);
        initComponents();
        Toolkit tk = Toolkit.getDefaultToolkit();
        int xsize = (int) tk.getScreenSize().getWidth();
        int ysize = (int) tk.getScreenSize().getHeight();
        //this.setSize(xsize, ysize);

    }
    
    
    
    
   public class FuncionariobyCPF{
        ResultSet rs = null;
        OraclePreparedStatement ps = null;
        public ResultSet find(String s, Connection conn){
            try{
     
                String SQL = "select * from funcionario where PK_CPF_F = ?";
                
                ps = (OraclePreparedStatement)conn.prepareStatement(SQL);                             
                ps.setString(1, s);
                rs = ps.executeQuery();
                
               
            } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
            } catch (Exception e) {
            }
            
                
            
            return rs;
        }
    }
    
    public class PagamentobyCPF{
        ResultSet rs = null;
        OraclePreparedStatement ps = null;
        public ResultSet find(String s, Connection conn){
            try{
                

                String SQL = "select * from pagamento where FK_PK_CPF_F = ?";
                
                ps = (OraclePreparedStatement)conn.prepareStatement(SQL);                             
                ps.setString(1, s);
                rs = ps.executeQuery();
                
                
            } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
            } catch (Exception e) {
                System.out.println(e);
            }
            
            return rs;
        } 
    }
    
     public class FuncCargobyCPF{
        ResultSet rs = null;
        OraclePreparedStatement ps = null;
        public ResultSet find(String s, Connection conn){
            try{
                

                String SQL = "select * from Funcionario_Cargo where FK_PK_CPF_F = ? and DATA_FIM is null";
                
                ps = (OraclePreparedStatement)conn.prepareStatement(SQL);                             
                ps.setString(1, s);
                rs = ps.executeQuery();
                
                
            } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
            } catch (Exception e) {
            }
            return rs;
        } 
    }
    
    public class CargobyID{
        ResultSet rs = null;
        OraclePreparedStatement ps = null;
        public ResultSet find(String s, Connection conn){
            try{
              

                String SQL = "select * from Cargo where Cod_C = ?";
                
                ps = (OraclePreparedStatement)conn.prepareStatement(SQL);                             
                ps.setString(1, s);
                rs = ps.executeQuery();
                
                 
            } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
            } catch (Exception e) {
            }
            return rs;
        } 
       
    }
    
   public float INSS(Float SalarioBruto){
        float totalInss;
        
        if(SalarioBruto <= 1556.94)
            totalInss = 0.08f * SalarioBruto;
        else if(SalarioBruto <= 2594.92)
            totalInss = 0.09f * SalarioBruto;
        else if(SalarioBruto <= 5189.82)
            totalInss = 0.11f * SalarioBruto;
        else
            totalInss = 570.88f;
        return totalInss;
    }
    
    public float FGTS(float SalarioBruto){
        return SalarioBruto*0.08f;
    }
    
    public void calcImpostos(String CPF) throws SQLException{
        String cod = null, horatrab = null, AdComissao_P = null, AdInsalubridade_P = null, AdPericulosidade_P = null;
        Float SalarioBase = 0f, ValorHora = 0f, HoraExtraReais = 0f, inss = 0f, fgts = 0f, SalarioBruto = 0f;
        ResultSet rs = null, rs2 = null, rs3 = null, rs4 = null;
        
        FuncionariobyCPF f = new FuncionariobyCPF();
        PagamentobyCPF f2 = new PagamentobyCPF();
        FuncCargobyCPF f3 = new FuncCargobyCPF();
        CargobyID f4 = new CargobyID();
        
        OracleConnectionPoolDataSource ds = new OracleConnectionPoolDataSource();
                ds.setURL("jdbc:oracle:thin:@localhost:1521:xe");
                ds.setUser("folhapagamento");
                ds.setPassword("SENHA");
                PooledConnection pc = ds.getPooledConnection();
                Connection conn=pc.getConnection();
        
        
        rs = f.find(CPF, conn);
        rs2 = f2.find(CPF, conn);
        rs3 = f3.find(CPF, conn);
        try{
            if(rs2.next()){
                horatrab = rs2.getString("HORASEXTRATRABALHADAS");
                AdComissao_P = rs2.getString("AdComissao_P");
                AdInsalubridade_P = rs2.getString("AdInsalubridade_P");
                AdPericulosidade_P = rs2.getString("AdPericulosidade_P");
            }
            if(rs3.next()){
                cod = rs3.getString("fk_pk_Cod_C");
                rs4 = f4.find(cod, conn); 
            }
            if(rs4.next()){
                    SalarioBase= parseFloat(rs4.getString("Valor_base"));
                    ValorHora = parseFloat(rs4.getString("Valor_horaTrab"));   
             }
            
            if(horatrab != null){
                  HoraExtraReais = (ValorHora + ValorHora * 0.5f) * parseFloat(horatrab) ;  //adicional de 50% do valor da hora extra.
                  System.out.println(HoraExtraReais);
            }
            
            SalarioBruto = SalarioBase + HoraExtraReais;
            
            if(AdComissao_P != null){
                SalarioBruto = SalarioBruto + parseFloat(AdComissao_P);
            }
            if(AdPericulosidade_P != null){
                SalarioBruto = SalarioBruto + parseFloat(AdPericulosidade_P);
            }
            if(AdInsalubridade_P != null){
                SalarioBruto = SalarioBruto + parseFloat(AdInsalubridade_P);
            }
            if(AdComissao_P != null){
                SalarioBruto = SalarioBruto + parseFloat(AdComissao_P);
            }
            
            inss = INSS(SalarioBruto);
            fgts = FGTS(SalarioBruto);
            System.out.println(SalarioBruto);
            System.out.println(inss);
            System.out.println(fgts);
            
            
           
            
            updatePagamento("Fgts_P", CPF, fgts, conn);
            updatePagamento("INSS_P", CPF, inss, conn);
            updatePagamento("AdHoraExtra_P", CPF, HoraExtraReais, conn);
            
                 try {
                    rs.close();
                    pc.close();
                    conn.close();
                    Thread.sleep(500);
                }
                catch(Exception e) { }
            
            
            
            /*resultSetClose(rs);
            resultSetClose(rs2);
            resultSetClose(rs3);
            resultSetClose(rs4);
           */
            
            //JOptionPane.showMessageDialog(null, "Salario: "+SalarioBase +" Valor hora: "+ ValorHora );
        }catch(Exception ex){
        }
        
        
        
    
    }
    
    public void updatePagamento(String Campo, String CPF, Float Dado, Connection conn) throws SQLException{
        ResultSet rs = null;
        OraclePreparedStatement ps = null;
        try{                 
            String SQL = "UPDATE pagamento SET " + Campo + " = ? where FK_PK_CPF_F ='" + CPF + "'";

            ps = (OraclePreparedStatement)conn.prepareStatement(SQL);  
            ps.setFloat(1, Dado);
            rs = ps.executeQuery();
            
            
            
        } catch (SQLException e) {
        System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        } 
        finally {
            if (rs != null)
              rs.close ();
            if (ps != null)
              ps.close ();
         }
        
        
        
        
    }
    
    
    
    
  
    
    public boolean SearchCPF(String CPF) {
        ResultSet rs = null;
        OraclePreparedStatement ps = null;
            try{
                OracleConnectionPoolDataSource ds = new OracleConnectionPoolDataSource();
                ds.setURL("jdbc:oracle:thin:@localhost:1521:xe");
                ds.setUser("folhapagamento");
                ds.setPassword("SENHA");
                PooledConnection pc = ds.getPooledConnection();
                Connection conn=pc.getConnection();
                
                String SQL = "SELECT * from pagamento where FK_PK_CPF_F ='" + CPF + "'";
                
                ps = (OraclePreparedStatement)conn.prepareStatement(SQL);
                rs = ps.executeQuery();
                if(rs.next()){
                    //JOptionPane.showMessageDialog(null, "CPF encontrado");
                    return true;
                }else{
                    JOptionPane.showMessageDialog(null, "Não existe folha de pagamento referente ao CPF informado");
                }
                 try {
                    ps.close();
                    conn.close();
                    Thread.sleep(500);
                }
                catch(Exception e) { }
                
            } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
            } catch (Exception e) {
            }
            return false;
    }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnDesconto = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        btnAdicional = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        btnDesconto.setText("Pagamento INSS/FGTS");
        btnDesconto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDescontoActionPerformed(evt);
            }
        });

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/logo-inss-previdencia-social2.png"))); // NOI18N

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/adicional.png"))); // NOI18N

        btnAdicional.setText("Bônus");
        btnAdicional.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAdicionalActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(262, 262, 262)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(55, 55, 55)
                        .addComponent(btnDesconto)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(77, 77, 77)
                        .addComponent(jLabel2))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(180, 180, 180)
                        .addComponent(btnAdicional)))
                .addContainerGap(270, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(192, 192, 192)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnAdicional, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnDesconto, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(220, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAdicionalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAdicionalActionPerformed
        // TODO add your handling code here:
        String CPF = null;
            do {
                CPF = JOptionPane.showInputDialog( "Informe o CPF");
                if (CPF == null) {
                    JOptionPane.showMessageDialog(null, "Ação cancelada");
                    break;
                } else {
                    if (validaCPF.isCPF(CPF) == true){
                        if(SearchCPF(CPF)){
                            Adicionais s;
                            try {
                                s = new Adicionais(CPF);
                                s.setVisible(true);
                            } catch (SQLException ex) {
                                Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                            dispose();
                        }
                    }else 
                        JOptionPane.showMessageDialog(null, "Erro, CPF invalido !!!");
       
                }   
            }while (validaCPF.isCPF(CPF) == false);
        
        
    }//GEN-LAST:event_btnAdicionalActionPerformed

    private void btnDescontoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDescontoActionPerformed
        // TODO add your handling code here:

            String CPF = null;
            do {
                CPF = JOptionPane.showInputDialog( "Informe o CPF");
                if (CPF == null) {
                    JOptionPane.showMessageDialog(null, "Ação cancelada");
                    break;
                } else {
                    if (validaCPF.isCPF(CPF) == true){
                        if(SearchCPF(CPF)){
                            pagamento s;
                            try {
                                s = new pagamento(CPF);
                                s.setVisible(true);

                            } catch (SQLException ex) {
                                Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            dispose();
                        }
                    }else 
                        JOptionPane.showMessageDialog(null, "Erro, CPF invalido !!!");
       
                }   
            }while (validaCPF.isCPF(CPF) == false);

    }//GEN-LAST:event_btnDescontoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Principal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAdicional;
    private javax.swing.JButton btnDesconto;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    // End of variables declaration//GEN-END:variables
}
